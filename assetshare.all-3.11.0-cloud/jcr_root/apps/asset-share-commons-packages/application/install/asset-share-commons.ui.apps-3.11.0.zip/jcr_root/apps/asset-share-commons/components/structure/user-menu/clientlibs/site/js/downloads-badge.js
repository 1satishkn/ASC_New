/*

Download Badge logic is managed in /apps/asset-share-commons/components/modals/downloads/clientlibs/site/js/downloads.js
as it currently has a tight coupling/dependency on the Downloads Modal itself

*/