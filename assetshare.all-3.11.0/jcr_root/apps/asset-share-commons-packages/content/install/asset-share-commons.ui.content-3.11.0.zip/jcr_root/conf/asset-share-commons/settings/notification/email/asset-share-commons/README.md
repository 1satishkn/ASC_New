# Asset Share Commons

## Sharing E-mail Template

The following variables are available for use in the E-mail Template.

### Provided via the Authored Component 

* Subject: `${subject}`
* Signature: `${signature}`

### Provided via End-User

* Shared Asset Links: `${assetLinksHTML}`
* Custom Message: `${message}`

